npm install
npm start
start "http://localhost:3000/"