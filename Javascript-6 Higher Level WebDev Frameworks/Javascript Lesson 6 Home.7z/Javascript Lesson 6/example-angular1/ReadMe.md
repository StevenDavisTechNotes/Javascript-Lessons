npm install
npm start