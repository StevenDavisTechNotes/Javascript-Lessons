var MyComponentCtrl = (function () {
    // Dependency injection via contrustor
    function MyComponentCtrl($scope) {
    }
    Object.defineProperty(MyComponentCtrl.prototype, "counter", {
        get: function () {
            return this.counterValue;
        },
        set: function (val) {
            this.counterValue = Number(val);
        },
        enumerable: true,
        configurable: true
    });
    MyComponentCtrl.prototype.decrement = function () {
        this.counter--;
    };
    MyComponentCtrl.prototype.increment = function () {
        this.counter++;
    };
    return MyComponentCtrl;
}());
MyComponentCtrl.AngularDependencies = ['$scope', MyComponentCtrl];
var angular;
angular.module('myApp').controller('MyComponentCtrl', MyComponentCtrl.AngularDependencies);
//# sourceMappingURL=MyComponentCtrl.js.map