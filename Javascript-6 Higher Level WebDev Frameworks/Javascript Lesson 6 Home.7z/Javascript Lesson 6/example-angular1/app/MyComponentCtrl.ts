class MyComponentCtrl { 
    static AngularDependencies = ['$scope', MyComponentCtrl];

    // Dependency injection via contrustor
    constructor($scope: any)
    {
    }
    
    private counterValue: number;

    get counter() {
        return this.counterValue;
    }

    set counter(val) {
        this.counterValue = Number(val);
    }

    decrement() {
        this.counter--;
    }

    increment() {
        this.counter++;
    }
}
var angular: any;
angular.module('myApp').controller(
	'MyComponentCtrl', MyComponentCtrl.AngularDependencies);