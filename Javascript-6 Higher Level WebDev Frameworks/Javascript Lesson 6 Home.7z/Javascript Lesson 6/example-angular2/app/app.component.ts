import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'msg-app',
  templateUrl: 'app/app.component.html', 
  styleUrls: ['app/app.component.css']
})
export class AppComponent { 

  private counterValue: number = 5;
  @Output() counterChange = new EventEmitter();

  @Input()
  get counter() {
    return this.counterValue;
  }

  set counter(val) {
    this.counterValue = Number(val);
    this.counterChange.emit(this.counterValue);
  }

  decrement() {
    this.counter--;
  }

  increment() {
    this.counter++;
  }
}
    