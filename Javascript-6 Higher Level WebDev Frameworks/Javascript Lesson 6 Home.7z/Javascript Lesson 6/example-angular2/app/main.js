"use strict";
var platform_browser_dynamic_1 = require('@angular/platform-browser-dynamic');
var module_1 = require('./module');
var platform = platform_browser_dynamic_1.platformBrowserDynamic();
platform.bootstrapModule(module_1.AppModule);
//# sourceMappingURL=main.js.map