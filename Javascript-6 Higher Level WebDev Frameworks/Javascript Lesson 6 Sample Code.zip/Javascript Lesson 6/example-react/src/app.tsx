import * as React from "react";
import * as ReactDOM from "react-dom";
import MyComponent from "./MyComponent";

ReactDOM.render(
    <MyComponent name="George" counter={7} />,
    document.getElementById("root")
);
