import * as React from "react";

interface IMyComponentProps {
    name: string;
    counter: number;
}
interface IMyComponentState {
    name: string;
    counter: number;
}
class MyComponent extends React.Component<IMyComponentProps, IMyComponentState> {
    constructor(props: IMyComponentProps) {
        super(props);
        this.state = {counter: props.counter, name: props.name};
        this.handleDecrement = this.handleDecrement.bind(this);
        this.handleIncrement = this.handleIncrement.bind(this);
        this.handleChange = this.handleChange.bind(this);
    }
    handleDecrement(event: any): void{
        this.setState({counter: this.state.counter-1, name: this.state.name});
    }
    handleIncrement(event: any): void {
        this.setState({counter: this.state.counter+1, name: this.state.name});
    }
    handleChange(event: any): void {
        this.setState({counter: Number(event.target.value), name: this.state.name});
    }
    render() {
        return (<div>
            <div><span>Hi {this.state.name}</span></div>
            <div>
                <button onClick={this.handleDecrement}>-</button>
                <span>{this.state.counter}</span>
                <button onClick={this.handleIncrement}>+</button>
            </div>
            <div><input type="text" value={String(this.state.counter)} onChange={this.handleChange}/></div>
            </div>);
    }
}

export default MyComponent;
