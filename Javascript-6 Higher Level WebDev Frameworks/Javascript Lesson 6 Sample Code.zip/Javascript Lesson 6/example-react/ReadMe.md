npm install
node_modules\.bin\typings i
npm run build