npm install
node_modules\.bin\jspm i
npm start