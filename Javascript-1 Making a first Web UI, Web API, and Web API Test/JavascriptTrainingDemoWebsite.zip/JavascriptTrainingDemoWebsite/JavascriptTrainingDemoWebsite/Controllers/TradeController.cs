﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using JavascriptTrainingDemoWebsite.Models;

namespace JavascriptTrainingDemoWebsite.Controllers
{
    public class TradeController : ApiController
    {
        Trade[] blotter = new []
        {
            new Trade { TradeId = 1, Quantity = 1234, Symbol = "MSFT", TimestampAdded=DateTime.Now, TimestampModified  = DateTime.Now, User = "SDavis"},
            new Trade { TradeId = 2, Quantity = 2345, Symbol = "INTC", TimestampAdded=DateTime.Now, TimestampModified  = DateTime.Now, User = "SDavis" },
            new Trade { TradeId = 3, Quantity = 3456, Symbol = "IBM", TimestampAdded=DateTime.Now, TimestampModified  = DateTime.Now, User = "SDavis" }
        };

        public IEnumerable<Trade> GetAllTrades()
        {
            return blotter;
        }

        [Route("api/trade/{tradeId}")]
        public IHttpActionResult GetTrade(int tradeId)
        {
            var product = blotter.FirstOrDefault((p) => p.TradeId == tradeId);
            if (product == null)
            {
                return NotFound();
            }
            return Ok(product);
        }
    }
}
