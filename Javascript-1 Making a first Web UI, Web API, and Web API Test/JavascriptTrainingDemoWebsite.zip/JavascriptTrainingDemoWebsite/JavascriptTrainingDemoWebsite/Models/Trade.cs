﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace JavascriptTrainingDemoWebsite.Models
{
    public class Trade
    {
        public int TradeId { get; set; }
        public int Quantity { get; set; }
        public string Symbol { get; set; }

        public DateTime TimestampAdded { get; set; }
        public DateTime TimestampModified { get; set; }
        public string User { get; set; }
    }
}